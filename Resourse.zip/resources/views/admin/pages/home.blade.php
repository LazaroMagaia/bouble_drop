@include("admin.template.header")

Dashboard

@include("admin.template.footer")