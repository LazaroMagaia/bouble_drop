@include("client.template.header")

        <div class="pages-banner">
            <div class="social-network">
                <a href=""><i class="fa-brands fa-facebook-f"></i></a>
                <a href=""><i class="fa-brands fa-instagram"></i></a>
                <a href=""><i class="fa-brands fa-youtube"></i></a>
            </div><!--social Network-->    
        </div>

        <h1 class="contacto_header">Entre em Contacto</h1>
</div>
<!---END HEADER-->

<div id="ContactVue"></div>
 
@include("client.template.footer")